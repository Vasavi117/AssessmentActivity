package com.rehlat.newsactivity

import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.http.*

interface RetrofitApi {

    @Headers("Content-Type: application/json")
    @GET
    fun getNews(@Url response: String): Call<JsonObject>
}