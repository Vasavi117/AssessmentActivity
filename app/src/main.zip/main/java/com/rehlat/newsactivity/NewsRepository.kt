package com.rehlat.newsactivity

import androidx.lifecycle.MutableLiveData
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NewsRepository {

    fun getNews(): MutableLiveData<JsonObject>{
        val data = MutableLiveData<JsonObject>()
        val connTime = 20L

        val gson = GsonBuilder()
            .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
            .create()
        val serviceUrl = "https://newsapi.org/v2/"
        val url = serviceUrl+ "top-headlines?country=us&category=business&apiKey=cc70841b70374ff7baae461fc11ea849"
        val retrofit = NetworkUtils().retrofitClient(connTime, serviceUrl, gson)
        val github = retrofit.create(RetrofitApi::class.java)
        val call = github.getNews(url)
        call.enqueue(object : Callback<JsonObject>{
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if(response.isSuccessful){
                    data.value = response.body()
                }else{
                    data.value = null
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
               data.value = null
            }

        })
        return data
    }
}
