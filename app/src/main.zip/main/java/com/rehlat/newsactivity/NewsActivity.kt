package com.rehlat.newsactivity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_news.*

class NewsActivity : AppCompatActivity() {

    lateinit var viewModel: ViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)

        viewModel = ViewModelProvider(this).get(ViewModel::class.java)

        iv_back.setOnClickListener {
            onBackPressed()
        }

        getNews()

    }

    private fun getNews() {
        viewModel.getNews().observe(this, Observer { response->
            if(response!=null){
                var newsResponse = Gson().fromJson(response, NewsResponse::class.java)
                setAdapter(newsResponse)
            }
        })
    }

    private fun setAdapter(newsResponse: NewsResponse) {
        if(newsResponse.articles!=null && newsResponse.articles.size>0){
            rv_news.layoutManager = LinearLayoutManager(this)
            rv_news.adapter = NewsAdapter(this, newsResponse.articles)
        }
    }
}